package chatapplication;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;    //Represents a precompiled SQL statement that can be executed multiple times.
import java.sql.SQLException;

public class Database {
    private Connection connection;
    public Database() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/chatappdb", "root", "Morya@123"); //Database Connection:
        } catch (SQLException e) {
            e.printStackTrace();   //This line prints the stack trace of the exception to the console
        }
    }

    
    public boolean saveUserName(String userName) {
        String query = "INSERT INTO users (username) VALUES (?)"; 
        try (PreparedStatement stmt = connection.prepareStatement(query)) { //creates a PreparedStatement object named stmt using the connection variable
            stmt.setString(1, userName);
            int rowsInserted = stmt.executeUpdate();  //actual excution of sql query
            return rowsInserted > 0; // Return true if insert was successful
        } catch (SQLException e) {
            e.printStackTrace();    
            return false; // Return false if there was an error
        }
    }

    // Method to close the database connection
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {   //This condition checks if the connection variable is not null
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
