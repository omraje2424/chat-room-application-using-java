package chatapplication;
import static chatapplication.MulticastClient.name; 
//This imports the static variable name from the MulticastClient class. This allows the MultiClient class to access and modify the name variable directly
import javax.swing.JOptionPane;
public class MultiClient {
    MultiClient() {
        name = JOptionPane.showInputDialog("Please enter your name");
        int count = 0;
        while (name == null || name.equals("")) {
            if (name == null) {
                new ChatApp().setVisible(true);    //creates a new instance of the ChatApp class and sets it to be visible
                count++;
                break;
            } else if (name.equals("")) {
                JOptionPane.showMessageDialog(new ChatApp(), "Please enter a proper name");
                name = JOptionPane.showInputDialog("Please enter your name");   //The new input is stored in the name variable.
            }
        }
        if (count == 0) {
            Database dbManager = new Database();
            boolean isSaved = dbManager.saveUserName(name); // calls the saveUserName method of the dbManager instance, attempting to save

            if (isSaved) {   //This condition checks if the name was successfully saved to the database.
                
                new MulticastClient().setVisible(true); //creates a new instance of the MulticastClient
                Thread t1 = new Thread(new Client());  // creates a new Thread object -> new instance of the Client class
                t1.start();  // starts the newly created thread
            } else {
                
                JOptionPane.showMessageDialog(new ChatApp(), "Error saving name to database. Please try again.");
            }
        }
    }
}
